#ifndef ANSWER_H
#define ANSWER_H
typedef struct answer{
  int bet1;
  int bet2;
  int bet3;
  int bet4;
}answer;
#endif
