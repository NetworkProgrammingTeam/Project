#ifndef RANDOM_HELPER_H
#define RANDOM_HELPER_H

int random_from_0_to_max(int);  /*random an int from 0 to max*/
int random_title_id(void);      /*random a title id*/
#endif
